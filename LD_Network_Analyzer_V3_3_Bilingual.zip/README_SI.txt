LD NETWORK ANALYZER – VERSION 3.0
=================================

මෙය Android Studio තුළ විවෘත කර APK එකක් Build කළ හැකි ආරම්භක Android Project එකකි.

Windows 10 හි භාවිතය:
1. Android Studio නිල වෙබ් අඩවියෙන් Install කරන්න.
2. ZIP ගොනුව Extract කරන්න.
3. Android Studio > Open තෝරා LD_Network_Analyzer_V2 folder එක තෝරන්න.
4. Gradle Sync අවසන් වන තෙක් රැඳී සිටින්න.
5. USB debugging සක්‍රීය කළ Android දුරකථනයක් සම්බන්ධ කර Run ඔබන්න.
6. APK එකක් සඳහා Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.

දැනට ඇතුළත්:
- LD Technology නාමය සහ Version 3.0 dashboard with dark navy / cyan visual design
- Android Telephony API හරහා signal dBm කියවීම (අවසර සහ උපාංග සහාය මත)
- LTE EARFCN / 5G NRARFCN cell තොරතුරු පෙන්වීමට මූලික පරීක්ෂාව
- Advanced analysis, speed test, band explorer, router analyzer සහ antenna assistant සඳහා interactive dashboard cards (feature screens are planned placeholders)

වැදගත් සීමා:
- සියලුම Android දුරකථන RSRQ/SINR/සම්පූර්ණ cell details ලබා නොදෙයි.
- Android සාමාන්‍ය API මඟින් universal LTE/5G band lock ලබාදෙන්නේ නැත.
- Dialog S50 ඇතුළු router සඳහා model-specific API/AT command/web interface පරීක්ෂා කළ යුතුය.
- Speed test card දැනට UI placeholder එකකි; විශ්වාසදායක server එකක් සහ පරීක්ෂණ ක්‍රමයක් එක් කළ යුතුය.
- App එක production-ready හෝ signed APK එකක් නොවේ.

Project package: com.ldtechnology.networkanalyzer
Version: 2.0 (versionCode 2)


V3.0 dashboard update:
- Added the LD Network Analyzer V3 cyber-tech wallpaper as a low-opacity dashboard background.
- Redesigned the home dashboard with live signal, network type and cell information cards.
- Added a two-column analysis tools grid. Tool screens are placeholders until their data sources and device support are implemented.
- Updated app version to 3.0 (versionCode 3).


V3.1 LIVE METRICS UPDATE:
- Fixed duplicate Compose annotation in the dashboard source.
- Fixed the permission-result flow so cell information refreshes after permission is granted.
- Added LTE PCI and band details when Android exposes them.
- Added 5G NR PCI and band details when Android exposes them.
- Added mobile operator name display.
- Updated app version to 3.1 (versionCode 4).

සටහන:
මෙම පරිසරයේ Android SDK / Gradle build environment නොමැති බැවින් APK build කර පරීක්ෂා කර නැත.
Android දුරකථනයේ සැබෑ දත්ත පෙන්වීම SIM, carrier, Android version සහ device API support මත රඳා පවතී.


V3.3 BILINGUAL DASHBOARD:
- English + Sinhala dashboard headings, tool names and explanatory text.
- Version metadata updated to 3.3.
- Existing live signal, LTE/NR cell and radio metric collection retained.
- This is a source-code update; an APK has not been built or tested in this environment.
