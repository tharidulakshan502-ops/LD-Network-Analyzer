package com.ldtechnology.networkanalyzer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellSignalStrengthLte
import android.telephony.CellSignalStrengthNr
import android.telephony.PhoneStateListener
import android.telephony.SignalStrength
import android.telephony.TelephonyManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Navy = Color(0xFF050D1B)
private val Panel = Color(0xE6102239)
private val Panel2 = Color(0xFF102B46)
private val Cyan = Color(0xFF21D4FD)
private val Blue = Color(0xFF1677F2)
private val Muted = Color(0xFF9BB4CC)

private data class RadioMetrics(
    val rsrp: String = "—",
    val rsrq: String = "—",
    val sinr: String = "—"
)

class MainActivity : ComponentActivity() {
    private var updateSignal: ((String) -> Unit)? = null
    private var updateRadioMetrics: ((RadioMetrics) -> Unit)? = null
    private var updateCellInfo: ((String) -> Unit)? = null
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshCellInfo { updateCellInfo?.invoke(it) }
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            updateNetworkInfo?.invoke(networkName(tm.dataNetworkType))
            tm.listen(phoneListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS)
        }
    }
    private var updateNetworkInfo: ((String) -> Unit)? = null

    private val phoneListener = object : PhoneStateListener() {
        override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
            super.onSignalStrengthsChanged(signalStrength)
            val strengths = signalStrength.cellSignalStrengths
            val dbm = strengths.firstOrNull()?.dbm
            updateSignal?.invoke(if (dbm != null && dbm < 0) "$dbm dBm" else "Unavailable")
            val lte = strengths.filterIsInstance<CellSignalStrengthLte>().firstOrNull()
            val nr = strengths.filterIsInstance<CellSignalStrengthNr>().firstOrNull()
            val metrics = when {
                nr != null -> RadioMetrics(
                    rsrp = nr.ssRsrp.takeIf { it != Int.MAX_VALUE }?.let { "$it dBm" } ?: "Unavailable",
                    rsrq = nr.ssRsrq.takeIf { it != Int.MAX_VALUE }?.let { "$it dB" } ?: "Unavailable",
                    sinr = nr.ssSinr.takeIf { it != Int.MAX_VALUE }?.let { "$it dB" } ?: "Unavailable"
                )
                lte != null -> RadioMetrics(
                    rsrp = lte.rsrp.takeIf { it != Int.MAX_VALUE }?.let { "$it dBm" } ?: "Unavailable",
                    rsrq = lte.rsrq.takeIf { it != Int.MAX_VALUE }?.let { "$it dB" } ?: "Unavailable",
                    sinr = lte.rssnr.takeIf { it != Int.MAX_VALUE }?.let { "${it / 10.0} dB" } ?: "Unavailable"
                )
                else -> RadioMetrics("Unavailable", "Unavailable", "Unavailable")
            }
            updateRadioMetrics?.invoke(metrics)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var signal by remember { mutableStateOf("Checking…") }
            var network by remember { mutableStateOf("Detecting network") }
            var cell by remember { mutableStateOf("Checking cell information…") }
            var radioMetrics by remember { mutableStateOf(RadioMetrics()) }
            var dialogTitle by remember { mutableStateOf<String?>(null) }
            updateSignal = { signal = it }
            updateRadioMetrics = { radioMetrics = it }
            updateCellInfo = { cell = it }
            updateNetworkInfo = { network = it }

            LaunchedEffect(Unit) {
                val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                network = networkName(tm.dataNetworkType)
                val needed = arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION)
                if (needed.all { ContextCompat.checkSelfPermission(this@MainActivity, it) == PackageManager.PERMISSION_GRANTED }) {
                    tm.listen(phoneListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS)
                    refreshCellInfo { cell = it }
                } else {
                    cell = "Allow phone and location permissions to inspect cell details"
                    permissionLauncher.launch(needed)
                }
            }

            MaterialTheme(colorScheme = darkColorScheme(
                background = Navy, surface = Panel2, primary = Cyan,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Box(Modifier.fillMaxSize().background(Navy)) {
                    Image(
                        painter = painterResource(R.drawable.ld_network_wallpaper),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().alpha(0.16f)
                    )
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99050D1B), Color(0xF2050D1B), Navy))))
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Header()
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("NETWORK DASHBOARD • ජාල පුවරුව", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                                Text("Your connection at a glance • ඔබේ ජාල තත්ත්වය", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Surface(color = Color(0xFF103A3A), shape = CircleShape) {
                                Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(7.dp).background(Color(0xFF4DE0A8), CircleShape))
                                    Spacer(Modifier.width(6.dp))
                                    Text("LIVE", color = Color(0xFF70E8B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        SignalCard(network, signal, cell)
                        RadioMetricsCard(radioMetrics)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard("NETWORK", network, Icons.Default.CellTower, Modifier.weight(1f))
                            MetricCard("SIGNAL", signal, Icons.Default.SignalCellularAlt, Modifier.weight(1f))
                        }
                        NetworkInfoCard(this@MainActivity)
                        SectionTitle("ANALYSIS TOOLS • විශ්ලේෂණ මෙවලම්", "Explore your network • ඔබේ ජාලය පරීක්ෂා කරන්න")
                        ToolGrid(onSelect = { dialogTitle = it })
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xD9102B43)), shape = RoundedCornerShape(18.dp)) {
                            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = Cyan, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("DEVICE COMPATIBILITY • උපාංග ගැළපුම", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Spacer(Modifier.height(5.dp))
                                    Text("Band locking and router diagnostics depend on device support. This dashboard displays only information Android makes available. • Band Lock සහ Router පරීක්ෂණ උපාංග සහාය මත රඳා පවතී.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                                }
                            }
                        }
                        Text("LD TECHNOLOGY  •  ANALYZE · OPTIMIZE · STAY CONNECTED  •  විශ්ලේෂණය · වැඩිදියුණු කිරීම", color = Muted, fontSize = 9.sp, letterSpacing = 0.7.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 8.dp))
                    }
                }
                if (dialogTitle != null) {
                    AlertDialog(
                        onDismissRequest = { dialogTitle = null },
                        containerColor = Panel2,
                        title = { Text(dialogTitle!!, color = Cyan, fontWeight = FontWeight.Bold) },
                        text = { Text("This tool is planned for the next development step. Its functions will be enabled after the required device or server support is added.", color = Muted) },
                        confirmButton = { TextButton(onClick = { dialogTitle = null }) { Text("OK", color = Cyan) } }
                    )
                }
            }
        }
    }

    private fun networkName(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
        TelephonyManager.NETWORK_TYPE_NR -> "5G NR"
        TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_HSPAP -> "3G"
        TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS -> "2G"
        else -> "Network unavailable"
    }

    private fun refreshCellInfo(onResult: ((String) -> Unit)? = null) {
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        try {
            val found = tm.allCellInfo.orEmpty().firstNotNullOfOrNull { info ->
                when (info) {
                    is CellInfoLte -> {
                        val id = info.cellIdentity
                        val bands = if (android.os.Build.VERSION.SDK_INT >= 30) id.bands.joinToString(", ").ifBlank { "Not reported" } else "Not supported"
                        "LTE  •  EARFCN ${id.earfcn}  •  PCI ${id.pci}  •  Band $bands"
                    }
                    is CellInfoNr -> {
                        val id = info.cellIdentity
                        val bands = if (android.os.Build.VERSION.SDK_INT >= 29) id.bands.joinToString(", ").ifBlank { "Not reported" } else "Not supported"
                        "5G NR  •  NRARFCN ${id.nrarfcn}  •  PCI ${id.pci}  •  Band $bands"
                    }
                    else -> null
                }
            } ?: "No LTE / NR cell details returned by device"
            onResult?.invoke(found)
        } catch (_: Exception) { onResult?.invoke("Cell details unavailable on this device") }
    }

    override fun onDestroy() {
        try { (getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).listen(phoneListener, PhoneStateListener.LISTEN_NONE) } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.ld_technology_brand), contentDescription = "LD Technology", contentScale = ContentScale.Fit, modifier = Modifier.size(48.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("LD TECHNOLOGY", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text("NETWORK ANALYZER", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        }
        Surface(color = Color(0xFF123B59), shape = RoundedCornerShape(30.dp)) {
            Text("V3.3", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp))
        }
    }
}

@Composable
private fun SignalCard(network: String, signal: String, cell: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x5532CFFF))
    ) {
        Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xCC123B5C), Color(0xAA0A1A30)))).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CellTower, contentDescription = null, tint = Cyan, modifier = Modifier.size(25.dp))
                Spacer(Modifier.width(9.dp))
                Text("PRIMARY CONNECTION • ප්‍රධාන සම්බන්ධතාව", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.weight(1f))
                Text(network, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
            Text(signal, color = Cyan, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
            Text("Signal strength • සංඥා ශක්තිය", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(17.dp))
            HorizontalDivider(color = Color(0x553C6584))
            Spacer(Modifier.height(12.dp))
            Text("CELL INFORMATION • සෙල් තොරතුරු", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(5.dp))
            Text(cell, color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
private fun RadioMetricsCard(metrics: RadioMetrics) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x4432CFFF))
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Analytics, contentDescription = null, tint = Cyan, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(8.dp))
                Text("LIVE RADIO METRICS • සජීවී රේඩියෝ දත්ත", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RadioMetric("RSRP", metrics.rsrp, Modifier.weight(1f))
                RadioMetric("RSRQ", metrics.rsrq, Modifier.weight(1f))
                RadioMetric("SINR", metrics.sinr, Modifier.weight(1f))
            }
            Text("Android supplies these values; availability depends on phone and network support. • මෙම දත්ත දුරකථනය සහ ජාලය අනුව වෙනස් විය හැක.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun RadioMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF0B1B2D), RoundedCornerShape(12.dp)).padding(9.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun MetricCard(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(9.dp))
            Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun NetworkInfoCard(context: Context) {
    val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    val operator = remember {
        runCatching { tm.networkOperatorName.takeIf { it.isNotBlank() } ?: "Unavailable" }.getOrDefault("Unavailable")
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x332BCBFA))
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.SimCard, contentDescription = null, tint = Cyan, modifier = Modifier.size(23.dp))
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("MOBILE OPERATOR • ජාල සේවා සපයන්නා", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(operator, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Text("ANDROID RADIO", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionTitle(eyebrow: String, title: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(eyebrow, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun ToolGrid(onSelect: (String) -> Unit) {
    val tools = listOf(
        Triple("Signal Analysis • සංඥා", "RSRP · RSRQ · SINR", Icons.Default.Analytics),
        Triple("Speed Test • වේගය", "Download · Upload · Ping", Icons.Default.Speed),
        Triple("Band Explorer • Band", "LTE / 5G band details", Icons.Default.Tune),
        Triple("Router Analyzer • Router", "Router diagnostics", Icons.Default.Router),
        Triple("Antenna Assistant • ඇන්ටෙනා", "Signal aiming guide", Icons.Default.SettingsInputAntenna),
        Triple("Network Info • ජාලය", "SIM · operator · type", Icons.Default.NetworkCheck)
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        tools.chunked(2).forEach { rowTools ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowTools.forEach { item ->
                    ToolTile(item.first, item.second, item.third, Modifier.weight(1f)) { onSelect(item.first) }
                }
                if (rowTools.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ToolTile(title: String, subtitle: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x332BCBFA))) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(Modifier.size(38.dp).background(Color(0xFF123B59), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(21.dp))
            }
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 9.sp, lineHeight = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("OPEN • විවෘත කරන්න", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Cyan, modifier = Modifier.size(12.dp))
            }
        }
    }
}
